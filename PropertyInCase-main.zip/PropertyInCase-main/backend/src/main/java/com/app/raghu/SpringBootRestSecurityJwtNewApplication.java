package com.app.raghu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestSecurityJwtNewApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestSecurityJwtNewApplication.class, args);
	}

}
