package com.app.raghu.files;

import lombok.Data;
import org.springframework.lang.NonNull;

import javax.persistence.*;
import java.time.LocalDateTime;


@Data
@Entity
@Table(name="cases")
public class Cases {
    @Id
    @GeneratedValue
    private Integer id;
    @Column(unique = true)
    private String case_number;
    private String title;
    private String description;
    private String status;
    private LocalDateTime created_at;
    private LocalDateTime updated_at;
}
