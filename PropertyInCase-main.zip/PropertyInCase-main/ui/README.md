

```bash
pnpm install --ignore-scripts

pnpm run dev

npm install --force

```
