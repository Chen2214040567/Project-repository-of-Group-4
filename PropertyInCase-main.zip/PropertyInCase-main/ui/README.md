

#### 安装依赖，运行测试  
```bash
npm install 
npm run dev
```


#### 下载代码，更新代码  
```bash
下载代码
git clone 代码仓库
更新代码
git pull

```

#### 安装pnpm 
```bash
npm install -g pnpm  
pnpm config set registry https://registry.npmmirror.com --global  
pnpm config list  
```


#### 编译
```bash
pnpm install --ignore-scripts --force
pnpm run dev
```


#### 提交代码
```bash
git status
git add .
git commit -a -m 版本主要工作说明
git push
```

### 用户和权限  
模块名称：UserPermissions  
组长： 彭梓涛  
```bash
1.2用户表： 王勇强、潘振云
1.3角色表： 庄朝阳、梁炜豪
1.4权限表： 黄桂坤、邓思希
1.5用户角色关联表：陈微如、黄小妹
1.6角色权限关联表：韦爱琴、唐冬梅
```

### 案情与流转模块      
模块名称：    
组长： 王胜杰  
```bash
案情表：钟晓欣、唐永宏、莫康为
法院表：蒙学忠、梁蕊珍
案件流转表：梁炎明、张立鹏、姚宗彬
涉案财务表：郑梦霖、罗创裕
案件档案表：韦丽霞、陈晨
```

### 入库与流转    
模块名称：RuKu    
组长： 王胜杰  
```bash
物料表   黄荣萧-胡子林
仓库表   覃鹏珲-沈爱斌
库存表   韦淑玟-韦石桥
调拨单   易广路-李秋萍
调拨详情表   胡冰雨-胡海林
仓库出入库   周胜-徐凤兰
```


### 现场管理     
模块名称：    
组长： 辛俊峰  
```bash
环境状态表 :  张灿阳 许纤纤
财物状态表：黄莉莉 杨金条
访问权限表：龚兆忠 黄乃威
访问日志表：江组衡 阎皓安
监控设备表:   莫睿平 莫筱婷
安全告警表：陆汉旺 张灿阳
巡查记录表：黄宝峰 辛俊峰
```