// // src/services/caseTransferApi.ts
// import axios from "axios";
// import { CaseTransferFormData } from "../types";

// const API_URL = "http://你的后端地址/api/case_transfers";

// // 获取案件流转记录
// export const getCaseTransfers = async () => {
//   const response = await axios.get(`${API_URL}`);
//   return response.data;
// };

// // 创建新的案件流转记录
// export const createCaseTransfer = async (data: CaseTransferFormData) => {
//   const response = await axios.post(API_URL, data);
//   return response.data;
// };
