

const Flow_analysis = ()=>{
  return(
    <>
      <h1>出入库和流转分析</h1>
    </>
  )
}


export default Flow_analysis
