

const visualization = ()=>{
  return(
    <>
      <h1>数据图表和可视化建议</h1>
    </>
  )
}


export default visualization
