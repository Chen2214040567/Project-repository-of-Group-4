

const Record_analysis = ()=>{
  return(
    <>
      <h1>巡查和监控记录分析</h1>
    </>
  )
}


export default Record_analysis
