import React, { useState } from 'react';
import { Card, Row, Col, Table } from 'antd';
import { Line } from '@ant-design/charts';

// 先在 package.json 中添加或更新以下内容：
// "dependencies": {
//   "react": "^18.3.1",
//   "@ant-design/charts": "^1.2.1",主要是这个需要下载
// }这是解决依赖问题的

const SupervisoryControl: React.FC = () => {
  const [selectedWarehouseId, setSelectedWarehouseId] = useState<number | null>(null);

  // 随机生成温湿度数据
  const generateTempHumidityData = () => {
    const hours = [
      '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00'
    ];
    const data = [];
    for (let i = 0; i < hours.length; i++) {
      const hour = hours[i];
      const temperature = Math.floor(Math.random() * 13 + (i < 5 || i > 9 ? 15 : 23)); // 早晨/晚间温度15-22，中午23-27
      const humidity = Math.floor(Math.random() * 21 + (i < 5 || i > 9 ? 30 : 50)); // 早晨/晚间湿度30-50，中午50-30
      data.push(
        { recordedAt: `2024-11-01 ${hour}`, value: temperature, type: '温度' },
        { recordedAt: `2024-11-01 ${hour}`, value: humidity, type: '湿度' }
      );
    }
    return data;
  };

  const tempHumidityData = generateTempHumidityData();

  // 模拟的异常环境记录
  const exceptionRecords = [
    { warehouse: '仓库 A', timestamp: '2024-11-01 08:00', location: 'A区', status: '已处理' },
    { warehouse: '仓库 B', timestamp: '2024-11-01 09:00', location: 'B区', status: '未处理' },
    { warehouse: '仓库 C', timestamp: '2024-11-01 10:00', location: 'C区', status: '未处理' },
    { warehouse: '仓库 D', timestamp: '2024-11-01 11:00', location: 'D区', status: '已处理' },
    { warehouse: '仓库 E', timestamp: '2024-11-01 12:00', location: 'E区', status: '未处理' },
    { warehouse: '仓库 F', timestamp: '2024-11-01 13:00', location: 'F区', status: '已处理' },
    // 更多模拟数据...
  ];

  // 配置折线图（温湿度趋势）
  const lineConfig = {
    data: tempHumidityData,
    xField: 'recordedAt',
    yField: 'value',
    seriesField: 'type',
    color: ['#ff7300', '#007acc'],
  };

  // 仓库点击事件
  const handleWarehouseClick = (warehouseId: number) => {
    setSelectedWarehouseId(warehouseId);
  };

  // 随机生成区的温湿度数据
  const generateZoneTempHumidity = () => {
    const zones = ['A', 'B', 'C', 'D', 'E', 'F'];
    return zones.map(zone => ({
      zone,
      temperature: Math.floor(Math.random() * 13 + 20), // 随机温度 20~32
      humidity: Math.floor(Math.random() * 21 + 30), // 随机湿度 30~50
    }));
  };

  const zoneData = generateZoneTempHumidity();

  return (
    <div>
      <h1>存储环境监控</h1>
      <Row gutter={[16, 16]}>
        {/* 温湿度监控图表 */}
        <Col span={24}>
          <Card title="温湿度监控图表">
            <Row>
              {/* 仓库列表 */}
              <Col span={4}>
                {['A', 'B', 'C', 'D', 'E', 'F'].map((id, idx) => (
                  <Card.Grid
                    key={idx}
                    style={{ width: '100%', cursor: 'pointer' }}
                    onClick={() => handleWarehouseClick(idx + 1)}
                  >
                    仓库 {id}
                  </Card.Grid>
                ))}
              </Col>
              {/* 折线图 */}
              <Col span={20}>
                {selectedWarehouseId && <Line {...lineConfig} />}
              </Col>
            </Row>
          </Card>
        </Col>

        {/* 异常环境记录 */}
        <Col span={12}>
          <Card title="异常环境记录">
            <Table
              dataSource={exceptionRecords}
              pagination={{ pageSize: 10 }}
              columns={[
                { title: '仓库名', dataIndex: 'warehouse', key: 'warehouse' },
                { title: '发生时间', dataIndex: 'timestamp', key: 'timestamp' },
                { title: '仓库位置', dataIndex: 'location', key: 'location' },
                { title: '处理情况', dataIndex: 'status', key: 'status' },
              ]}
            />
          </Card>
        </Col>

        {/* 实时环境数据展示 */}
        <Col span={12}>
          <Card title="实时环境数据展示">
            <Row gutter={[16, 16]}>
              {zoneData.map((zoneData, idx) => (
                <Col span={8} key={idx}>
                  <Card
                    title={`区 ${zoneData.zone}`}
                    style={{
                      height: '100%',
                      display: 'flex',
                      justifyContent: 'center',
                      flexDirection: 'column',
                      alignItems: 'center',
                    }}
                  >
                    <div style={{ color: 'orange', fontSize: 18 }}>
                      温度: {zoneData.temperature}°C
                    </div>
                    <div style={{ color: 'blue', fontSize: 18 }}>
                      湿度: {zoneData.humidity}%
                    </div>
                  </Card>
                </Col>
              ))}
            </Row>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default SupervisoryControl;