

const Stock_status = ()=>{
  return(
    <>
      <h1>财物盘点和库存状态</h1>
    </>
  )
}


export default Stock_status
