

const Disposal_analysis = ()=>{
  return(
    <>
      <h1>报废与处置分析</h1>
    </>
  )
}


export default Disposal_analysis
