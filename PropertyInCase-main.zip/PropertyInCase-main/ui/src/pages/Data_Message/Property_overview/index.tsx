

const Property_overview = ()=>{
  return(
    <>
      <h1>涉案财物总览</h1>
    </>
  )
}


export default Property_overview
