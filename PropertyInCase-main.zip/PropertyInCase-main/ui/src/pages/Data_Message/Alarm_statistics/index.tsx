

const Alarm_statistics = ()=>{
  return(
    <>
      <h1>安全事件与告警统计</h1>
    </>
  )
}


export default Alarm_statistics
