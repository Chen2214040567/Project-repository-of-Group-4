import React, { useState } from 'react';
import { Modal, Form, Input, Button } from 'antd';
import { MinusCircleOutlined } from '@ant-design/icons';

interface FactsModalFormProps {
    title: string;
    visible: boolean;
    onCancel: () => void;
    onSubmit: (values: any) => void;
    initialValues?: any;
}

const ModalForm: React.FC<FactsModalFormProps> = ({ title, visible, onCancel, onSubmit, initialValues }) => {
    const [form] = Form.useForm();
 
    useState(() => {
        if (initialValues) {
            form.setFieldsValue(initialValues);
        }
    }, [initialValues]);
 
    const onFinish = (values: any) => {
        onSubmit(values);
    };
 
    return (
        <Modal
            title={title}
            visible={visible}
            onCancel={onCancel}
            onOk={() => form.validateFields().then(onFinish)}
        >
            <Form form={form} layout="vertical">
                <Form.Item
                    label="案件ID"
                    name="case_id"
                    rules={[{ required: true, message: '请输入案件ID' }]}
                >
                    <Input />
                </Form.Item>
                <Form.Item
                    label="文件ID"
                    name="file_id"
                    rules={[{ required: true, message: '请输入文件ID' }]}
                >
                    <Input />
                </Form.Item>
                <Form.Item>
                    <Button type="link" onClick={onCancel} danger>
                        <MinusCircleOutlined /> 取消
                    </Button>
                </Form.Item>
            </Form>
        </Modal>
    );
};
 
export default ModalForm;