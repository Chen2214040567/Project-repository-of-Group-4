import React, { useState, useEffect } from 'react';
import { Table, Button, Popconfirm, Input, Form, message } from 'antd';
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';
// 引入模态框组件
import ModalForm from "./FactsModalForm";

import {fetchCaseFiles, createCaseFile, updateCaseFile, deleteCaseFile} from '../service';
import {FactsCaseFile, FactsCaseFilesType} from '../types';

interface CaseFilesTableProps {
    useMockData?: boolean; // 新增 prop 来控制是否使用模拟数据
}

const layout = {
    labelCol: { span: 8 },
    wrapperCol: { span: 16 },
};
 
const tailLayout = {
    wrapperCol: { offset: 8, span: 16 },
};

const FactsCaseFilesTable: React.FC<CaseFilesTableProps> = ({useMockData = false}) => {
    const [caseFiles, setCaseFiles] = useState<FactsCaseFilesType>([]);
    // 加载动画
    const [loading, setLoading] = useState<boolean>(false);
    // 模态框显示隐藏，默认隐藏
    const [isModalVisible, setIsModalVisible] = useState<boolean>(false);
    const [editingRecord, setEditingRecord] = useState<Partial<FactsCaseFile> | null>(null);
    const [searchQuery, setSearchQuery] = useState<string>(''); // 新增查询输入框的状态
    const [form] = Form.useForm();

    // const dispatch = useDispatch();
    useEffect(() => {
        fetchData();
    }, [searchQuery]);// 依赖searchQuery，当searchQuery变化时重新获取数据

    const fetchData = async () => {
        setLoading(true);
        const data = await fetchCaseFiles({search: searchQuery},useMockData);
        setCaseFiles(data);
        setLoading(false);
    };

    const handleDelete = async (id: number) => {
        try {
            setLoading(true);
            await deleteCaseFile(id);
            fetchData();
            setLoading(false);
            message.success('删除成功');
        } catch (error) {
            message.error('删除失败');
        }
        
    };

    const handleSave = async (values: FactsCaseFile) => {
        try {
            setLoading(true);
            if (values.id) {
                await updateCaseFile(values.id, values);
            } else {
                await createCaseFile(values);
            }
            fetchData();
            setIsModalVisible(false);
            setEditingRecord(null);
            form.resetFields(); // 重置表单
            setLoading(false);
            message.success('保存成功');
        } catch (error) {
            message.error('保存失败');
        }
        
    };

    const handleEdit = (record: FactsCaseFile) => {
        // form.setFieldsValue(record); // 设置表单初始值
        setEditingRecord({ ...record });
        setIsModalVisible(true);
      };
     
    const handleAdd = () => {
        setEditingRecord({ id: undefined, case_id: 0, file_id: 0, createdAt: '' });
        setIsModalVisible(true);
    };
      
    const handleCancel = () => {
        // form.resetFields(); // 重置表单
        setIsModalVisible(false);
        setEditingRecord(null);
    };

    const columns = [
        {
          title: 'ID',
          dataIndex: 'id',
          key: 'id',
        },
        {
          title: '案件ID',
          dataIndex: 'case_id',
          key: 'case_id',
        },
        {
          title: '文件ID',
          dataIndex: 'file_id',
          key: 'file_id',
        },
        {
          title: '创建时间',
          dataIndex: 'createdAt',
          key: 'createdAt',
        },
        {
          title: '操作',
          key: 'action',
          render: ( record: FactsCaseFile) => (
            <>
              <a onClick={() => handleEdit(record)}>编辑</a>
              <Popconfirm title="确定删除?" onConfirm={() => handleDelete(record.id)}>
                <a>删除</a>
              </Popconfirm>
            </>
          ),
        },
    ];

    const mergedColumns = [...columns];

    // if (!editingRecord) {
    //     mergedColumns.push({
    //         title: '操作',
    //         key: 'operation',
    //         render: () => (
    //           <Button type="primary" onClick={() => setEditingRecord({ id: undefined, case_id: 0, file_id: 0, createdAt: '' })}>
    //             <PlusOutlined /> 新增
    //           </Button>
    //         ),
    //     });
    // } else {
    //     mergedColumns[mergedColumns.length - 1].render = () => (
    //         <Form form={form} layout="vertical" onFinish={handleSave}>
    //             <Form.Item
    //                 label="案件ID"
    //                 name="case_id"
    //                 rules={[{ required: true, message: '请输入案件ID' }]}
    //             >
    //                 <Input />
    //             </Form.Item>
    //             <Form.Item
    //                 label="文件ID"
    //                 name="file_id"
    //                 rules={[{ required: true, message: '请输入文件ID' }]}
    //             >
    //                 <Input />
    //             </Form.Item>
    //             <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
    //                 <Button type="primary" htmlType="submit">
    //                     保存
    //                 </Button>
    //                 <Button onClick={handleCancel} danger style={{ marginLeft: 8 }}>
    //                     <MinusCircleOutlined /> 取消
    //                 </Button>
    //             </Form.Item>
    //         </Form>
    //     );
    // }
    // 处理查询输入框
    // const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    //     setSearchQuery(e.target.value);
    // };

    return (
        <div>
            <Input.Search placeholder="输入查询条件" onSearch={value => setSearchQuery(value)} style={{ marginBottom: 16 }} allowClear/>
            <Button type="primary" onClick={handleAdd} style={{ marginBottom: 16 }}>
                新增
            </Button>
            <Table
            loading={loading}
            columns={mergedColumns}
            dataSource={caseFiles}
            rowClassName="editable-row"
            pagination={false}
            bordered
        />
        <ModalForm
                title={editingRecord ? '编辑案件文件' : '添加案件文件'}
                visible={isModalVisible}
                onCancel={handleCancel}
                onSubmit={handleSave}
                initialValues={editingRecord}
            />
        </div>
    )
}

export default FactsCaseFilesTable