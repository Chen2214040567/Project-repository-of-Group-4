import { request } from '@umijs/max';
import {FactsCaseFile, FactsCaseFileParams, FactsCaseFilesType} from "./types";

// 查
export async function fetchCaseFiles(params?: FactsCaseFileParams, useMockData = false): Promise<FactsCaseFilesType> {
  if (useMockData) {
      // 根据search参数过滤模拟数据
      const mockData = [
        {id: 1, case_id: 101, file_id: 201, createdAt: '2023-01-01T00:00:00'},
        {id: 2, case_id: 102, file_id: 202, createdAt: '2023-01-01T00:00:00'},
        {id: 3, case_id: 103, file_id: 203, createdAt: '2023-01-01T00:00:00'},
      ];
    return params?.search ? mockData.filter(file => file.case_id.toString().includes(params.search) || file.file_id.toString().includes(params.search)) : mockData;
    
  }
  return request('/api/facts_case_files', {
    method: 'GET',
    params,
});
};

// 增
export async function createCaseFile(factsCaseFile : FactsCaseFile): Promise<any> {
    return request('/api/facts_case_files', {
        method: 'POST',
        data: factsCaseFile,
    });
};

// 改
export async function updateCaseFile(id: number, updatedCaseFile: Partial<FactsCaseFile>): Promise<any> {
    return request(`/api/facts_case_files/${id}`, {
      method: 'PUT',
      data: updatedCaseFile,
    });
};

// 删
export async function deleteCaseFile(id: number): Promise<any> {
    return request(`/api/facts_case_files/${id}`, {
        method: 'DELETE',
    })
}