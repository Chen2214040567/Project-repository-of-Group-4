export interface FactsCaseFile {
    id: number;
    case_id: number;
    file_id: number;
    createdAt: string; // Date string format
}

export interface FactsCaseFileParams {
    case_id?: number;
    file_id?: number;
    search?: string; // 新增搜索参数
}

export type FactsCaseFilesType = FactsCaseFile[];