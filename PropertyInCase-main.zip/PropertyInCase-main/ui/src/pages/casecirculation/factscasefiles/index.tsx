import React from 'react';
import FactsCaseFilesTable from './components/FactsCaseFilesTable';
// import './index.less'; // 你可以根据需要添加样式
 
const FactsCaseFiles: React.FC = () => {
// 你可以在这里设置是否使用模拟数据
const useMockData = true; // 或者 false，根据你的需要

  return (
    <div className="case-files-page">
      <h2>案件文件管理</h2>
      <FactsCaseFilesTable useMockData={useMockData}/>{/* 传递 useMockData prop */}
    </div>
  );
};
 
export default FactsCaseFiles;