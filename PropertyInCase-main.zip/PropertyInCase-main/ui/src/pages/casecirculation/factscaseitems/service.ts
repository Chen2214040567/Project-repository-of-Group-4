
import { CaseItem } from './types';

const apiUrl = '/api/case-items';

// 更新模拟数据，包含案件ID、物品ID、数量、描述、创建时间、更新时间
const mockData: CaseItem[] = [
  {
    id: 1,
    case_id: 101,
    item_id: 201,
    quantity: 10,
    description: '涉案物品A',
    created_at: '2024-11-01',
    updated_at: '2024-11-05',
  },
  {
    id: 2,
    case_id: 102,
    item_id: 202,
    quantity: 5,
    description: '涉案物品B',
    created_at: '2024-11-02',
    updated_at: '2024-11-06',
  },
  {
    id: 3,
    case_id: 103,
    item_id: 203,
    quantity: 8,
    description: '涉案物品C',
    created_at: '2024-11-03',
    updated_at: '2024-11-07',
  },
];

// 获取案件涉案财物列表（模拟）
export const fetchData = async (
  setData: React.Dispatch<React.SetStateAction<CaseItem[]>>,
  setLoading: React.Dispatch<React.SetStateAction<boolean>>
) => {
  setLoading(true);
  setTimeout(() => {
    setData(mockData);  // 设置模拟数据
    setLoading(false);
  }, 1000);  // 模拟延迟1秒
};

// 提交数据
export const submitData = async (
  values: any,
  currentItem: CaseItem | null,
  setVisible: React.Dispatch<React.SetStateAction<boolean>>,
  fetchData: Function,
  setData: React.Dispatch<React.SetStateAction<CaseItem[]>>,
  setLoading: React.Dispatch<React.SetStateAction<boolean>>
) => {
  try {
    if (currentItem) {
      // 编辑数据
      const updatedItem = { ...currentItem, ...values, updated_at: new Date().toISOString() };
      const index = mockData.findIndex(item => item.id === currentItem.id);
      if (index !== -1) {
        mockData[index] = updatedItem;
      }
    } else {
      // 新增数据
      const newItem: CaseItem = { id: Date.now(), ...values, created_at: new Date().toISOString(), updated_at: new Date().toISOString() };
      mockData.push(newItem);
    }
    setVisible(false);
    fetchData(setData, setLoading); // 重新加载数据
  } catch (error) {
    console.error('Error in submitting form', error);
  }
};

// 删除数据
export const deleteData = async (
  id: number,
  fetchData: Function,
  setData: React.Dispatch<React.SetStateAction<CaseItem[]>>,
  setLoading: React.Dispatch<React.SetStateAction<boolean>>
) => {
  try {
    // 删除模拟数据
    const updatedData = mockData.filter(item => item.id !== id);
    setData(updatedData);
    fetchData(setData, setLoading); // 重新加载数据
  } catch (error) {
    console.error('Error deleting item', error);
  }
};













