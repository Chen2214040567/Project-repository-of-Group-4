

import React, { useEffect, useState } from 'react';
import { Space } from 'antd';
import { CaseItem } from './types';
import { fetchData, submitData, deleteData } from './service';
import FactsCaseItemsTable from './components/FactsCaseItensTable';
import FactsModalForm from './components/FactsModalForm';

const ItemPage: React.FC = () => {
  const [data, setData] = useState<CaseItem[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [visible, setVisible] = useState<boolean>(false);
  const [currentItem, setCurrentItem] = useState<CaseItem | null>(null);

  // 获取案件涉案财物列表
  useEffect(() => {
    fetchData(setData, setLoading);
  }, []);

  // 编辑或新增数据
  const handleSubmit = async (values: any) => {
    await submitData(values, currentItem, setVisible, fetchData, setData, setLoading);
  };

  // 删除数据
  const handleDelete = async (id: number) => {
    await deleteData(id, fetchData, setData, setLoading);
  };

  // 打开编辑/新增表单
  const handleOpen = (item: CaseItem | null) => {
    setCurrentItem(item);
    setVisible(true);
  };

  // 关闭表单
  const handleClose = () => {
    setVisible(false);
    setCurrentItem(null);
  };

  return (
    <div>
      <Space direction="vertical" style={{ width: '100%' }}>
        <FactsCaseItemsTable data={data} loading={loading} handleOpen={handleOpen} />
        <FactsModalForm
          visible={visible}
          currentItem={currentItem}
          handleClose={handleClose}
          handleSubmit={handleSubmit}
        />
      </Space>
    </div>
  );
};

export default ItemPage;


