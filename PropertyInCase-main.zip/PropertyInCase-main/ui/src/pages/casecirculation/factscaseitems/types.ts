

export interface CaseItem {
  id: number;
  case_id: number;
  item_id: number;
  quantity: number;
  description: string;
  created_at: string;  // 使用字符串格式的日期
  updated_at: string;  // 使用字符串格式的日期
}
