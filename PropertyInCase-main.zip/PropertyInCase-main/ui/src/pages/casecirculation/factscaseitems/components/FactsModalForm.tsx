


import React from 'react';
import { Modal, Form, Input, Row, Col, Button } from 'antd';
import { CaseItem } from '../types';

interface Props {
  visible: boolean;
  currentItem: CaseItem | null;
  handleClose: () => void;
  handleSubmit: (values: any) => void;
}

const FactsModalForm: React.FC<Props> = ({ visible, currentItem, handleClose, handleSubmit }) => {
  return (
    <Modal
      title={currentItem ? '编辑涉案物品' : '新增涉案物品'}
      visible={visible}
      onCancel={handleClose}
      footer={null}
    >
      <Form
        initialValues={{
          case_id: currentItem ? currentItem.case_id : undefined,
          item_id: currentItem ? currentItem.item_id : undefined,
          description: currentItem ? currentItem.description : '',
          quantity: currentItem ? currentItem.quantity : 1,  // 如果是新增，默认数量为 1
        }}
        onFinish={handleSubmit}
        layout="vertical"
      >
        <Row gutter={16}>
          <Col span={24}>
            <Form.Item
              label="案件ID"
              name="case_id"
              rules={[{ required: true, message: '请输入案件ID' }]}
            >
              <Input type="number" />
            </Form.Item>
          </Col>
          <Col span={24}>
            <Form.Item
              label="物品ID"
              name="item_id"
              rules={[{ required: true, message: '请输入物品ID' }]}
            >
              <Input type="number" />
            </Form.Item>
          </Col>
          <Col span={24}>
            <Form.Item
              label="描述"
              name="description"
              rules={[{ required: true, message: '请输入物品描述' }]}
            >
              <Input.TextArea rows={1} />
            </Form.Item>
          </Col>
          <Col span={24}>
            <Form.Item
              label="数量"
              name="quantity"
              rules={[{ required: true, message: '请输入物品数量' }]}
            >
              <Input type="number" min={1} />
            </Form.Item>
          </Col>
        </Row>

        <Form.Item>
          <Button type="primary" htmlType="submit">
            提交
          </Button>
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default FactsModalForm;
