
import React from 'react';
import { Button } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import { ProTable } from '@ant-design/pro-components';
import { CaseItem } from '../types';

const formatDate = (dateString: string): string => {
  const date = new Date(dateString);
  return date.toISOString().split('T')[0]; // 仅保留年月日
};

interface Props {
  data: CaseItem[];
  loading: boolean;
  handleOpen: (item: CaseItem | null) => void;
}

const FactsCaseItemsTable: React.FC<Props> = ({ data, loading, handleOpen }) => {
  return (
    <ProTable<CaseItem>
      rowKey="id"
      columns={[
        {
          title: '案件ID',
          dataIndex: 'case_id',
          hideInSearch: false,  // 显示在查询栏中
        },
        {
          title: '物品ID',
          dataIndex: 'item_id',
          hideInSearch: false,  // 显示在查询栏中
        },
        {
          title: '描述',
          dataIndex: 'description',
          hideInSearch: false,  // 显示在查询栏中
        },
        {
          title: '数量',
          dataIndex: 'quantity',
          hideInSearch: true,  // 不显示在查询栏中
        },
        {
          title: '创建时间',
          dataIndex: 'created_at',
          render: (text) => formatDate(text as string),  // 格式化日期为年月日
          hideInSearch: true,  // 不显示在查询栏中
        },
        {
          title: '更新时间',
          dataIndex: 'updated_at',
          render: (text) => formatDate(text as string),  // 格式化日期为年月日
          hideInSearch: true,  // 不显示在查询栏中
        },
      ]}
      dataSource={data}
      loading={loading}
      toolbar={{
        title: '案件涉案财物',
        tooltip: '新增案件涉案财物',
        actions: [
          <Button
            key="new"
            type="primary"
            icon={<PlusOutlined />}
            onClick={() => handleOpen(null)}
          >
            新增
          </Button>,
        ],
      }}
      search={{
        collapsed: false,  // 默认展开查询栏
        span: 6,           // 每个查询字段的宽度
        labelWidth: 'auto',  // 自动标签宽度
      }}
      pagination={{
        pageSize: 10,
      }}
    />
  );
};

export default FactsCaseItemsTable;




