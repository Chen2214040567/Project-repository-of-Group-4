
import { request } from '@umijs/max';
import { FactsCaseDetails } from './types';

export async function fetchCaseDetails(params?: Partial<FactsCaseDetails>) {
//   return request<FactsCaseDetails[]>('/api/facts_case_details', { params });

    return Promise.resolve([
      {
        id: 1,
        case_number: 'CN20231001',
        title: '案件1',
        description: '案件描述1',
        status: '在审',
        current_court_id: 1,
        created_at: '2023-10-01',
        updated_at: '2023-10-02',
        created_by: 1,
        updated_by: 2,
      },
      {
        id: 2,
        case_number: 'CN20231002',
        title: '案件2',
        description: '案件描述2',
        status: '在审',
        current_court_id: 2,
        created_at: '2023-10-01',
        updated_at: '2023-10-02',
        created_by: 1,
        updated_by: 2,
      },
      // 其他模拟数据
    ]);
  
  
}

export async function createCaseDetail(data: FactsCaseDetails) {
  return request('/api/facts_case_details', {
    method: 'POST',
    data,
  });
}

export async function updateCaseDetail(id: number, data: FactsCaseDetails) {
  return request(`/api/facts_case_details/${id}`, {
    method: 'PUT',
    data,
  });
}

export async function deleteCaseDetail(id: number) {
  return request(`/api/facts_case_details/${id}`, {
    method: 'DELETE',
  });
}
