
export interface FactsCaseDetails {
    id: number;
    case_number: string;
    title: string;
    description: string;
    status: string;
    current_court_id: number;
    created_at: string;
    updated_at: string;
    created_by: number;
    updated_by: number;
  }
  
  