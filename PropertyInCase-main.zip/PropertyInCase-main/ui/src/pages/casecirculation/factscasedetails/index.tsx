
import React from 'react';
import FactsCaseDetailsTable from './components/FactsCaseDetailsTable';

const FactsCaseDetailsPage: React.FC = () => {
  return (
    <div>
      <FactsCaseDetailsTable />
    </div>
  );
};

export default FactsCaseDetailsPage;

