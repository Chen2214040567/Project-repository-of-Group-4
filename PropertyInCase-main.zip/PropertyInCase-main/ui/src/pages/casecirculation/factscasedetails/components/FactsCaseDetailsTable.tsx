
import React, { useEffect, useState } from 'react';
import { Table, Button, Modal, Form, Input, Select, message } from 'antd';
import { FactsCaseDetails } from '../types';
import { fetchCaseDetails, createCaseDetail, updateCaseDetail, deleteCaseDetail } from '../service';

const FactsCaseDetailsTable: React.FC = () => {
  const [data, setData] = useState<FactsCaseDetails[]>([]);
  const [loading, setLoading] = useState(false);
  const [editingItem, setEditingItem] = useState<FactsCaseDetails | null>(null);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [searchParams, setSearchParams] = useState<Partial<FactsCaseDetails>>({});

  const loadData = async (params = {}) => {
    setLoading(true);
    try {
      const result = await fetchCaseDetails(params);
      setData(result);
    } catch (error) {
      message.error('加载数据失败');
    }
    setLoading(false);
  };

  useEffect(() => {
    loadData(searchParams);
  }, [searchParams]);

  const handleSearch = (values: Partial<FactsCaseDetails>) => {
    setSearchParams(values);
  };

  const handleReset = () => {
    setSearchParams({});
  };

  const handleEdit = (item: FactsCaseDetails) => {
    setEditingItem(item);
    setIsModalVisible(true);
  };

  const handleDelete = async (id: number) => {
    await deleteCaseDetail(id);
    message.success('删除成功');
    loadData(searchParams);
  };

  const handleFormSubmit = async (values: any) => {
    if (editingItem) {
      await updateCaseDetail(editingItem.id, values);
      message.success('更新成功');
    } else {
      await createCaseDetail(values);
      message.success('创建成功');
    }
    loadData(searchParams);
    setIsModalVisible(false);
  };

  return (
    <>
      <Form layout="inline" onFinish={handleSearch} onReset={handleReset} style={{ marginBottom: 16 }}>
        <Form.Item name="case_number" label="案件编号">
          <Input placeholder="请输入案件编号" />
        </Form.Item>
        <Form.Item name="case_title" label="标题">
          <Input placeholder="请输入标题" />
        </Form.Item>
        <Form.Item name="status" label="状态">
          <Select placeholder="请选择状态" allowClear>
            <Select.Option value="在审">在审</Select.Option>
            <Select.Option value="结案">结案</Select.Option>
          </Select>
        </Form.Item>
        <Form.Item>
          <Button type="primary" htmlType="submit">
            查询
          </Button>
        </Form.Item>
        <Form.Item>
          <Button htmlType="reset">
            重置
          </Button>
        </Form.Item>
      </Form>

      <Button type="primary" onClick={() => { setEditingItem(null); setIsModalVisible(true); }}>
        新增案件
      </Button>

      <Table
        loading={loading}
        dataSource={data}
        rowKey="id"
        columns={[
          { title: '案件编号', dataIndex: 'case_number' },
          { title: '标题', dataIndex: 'title' },
          { title: '描述', dataIndex: 'description' },
          { title: '状态', dataIndex: 'status' },
          {
            title: '操作',
            render: (_, record) => (
              <>
                <Button type="link" onClick={() => handleEdit(record)}>编辑</Button>
                <Button type="link" danger onClick={() => handleDelete(record.id)}>删除</Button>
              </>
            ),
          },
        ]}
      />

      <Modal
        visible={isModalVisible}
        title={editingItem ? '编辑案件' : '新增案件'}
        onCancel={() => setIsModalVisible(false)}
        onOk={() => {
          document.querySelector('#caseDetailForm')?.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
        }}
      >
        <Form
          id="caseDetailForm"
          initialValues={editingItem || { status: '在审' }}
          onFinish={handleFormSubmit}
        >
          <Form.Item name="case_number" label="案件编号" rules={[{ required: true, message: '请输入案件编号' }]}>
            <Input />
          </Form.Item>
          <Form.Item name="title" label="标题" rules={[{ required: true, message: '请输入案件标题' }]}>
            <Input />
          </Form.Item>
          <Form.Item name="description" label="描述">
            <Input.TextArea />
          </Form.Item>
          <Form.Item name="status" label="状态" rules={[{ required: true }]}>
            <Select>
              <Select.Option value="在审">在审</Select.Option>
              <Select.Option value="结案">结案</Select.Option>
            </Select>
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};

export default FactsCaseDetailsTable;
