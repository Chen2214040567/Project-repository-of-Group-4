const Casesettings = () => {

    return (
        <>
            <div>
                <span>流转页</span>
            </div>
        </>
    )
}

export default Casesettings;