const Content = () => {

    return (
        <>
            <div>
                <span>案情页</span>
            </div>
        </>
    )
}

export default Content;