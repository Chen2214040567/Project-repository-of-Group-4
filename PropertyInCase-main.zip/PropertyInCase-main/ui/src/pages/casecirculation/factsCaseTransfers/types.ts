export interface CaseTransfer {
  id: number;
  case_id: number;
  from_court_id: number;
  to_court_id: number;
  transferred_by: number;
  transfer_date: string;
  reason: string;
  created_at: string;
}

export interface SearchParams {
  case_id: string;
  from_court_id: string;
  to_court_id: string;
}
