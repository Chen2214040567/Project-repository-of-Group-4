import { CaseTransfer } from './types';

export const fetchCaseTransfers = async (): Promise<CaseTransfer[]> => {
  // 模拟数据获取
  return [
    {
      id: 1,
      case_id: 101,
      from_court_id: 1,
      to_court_id: 2,
      transferred_by: 1001,
      transfer_date: '2024-11-01T10:00:00',
      reason: '案件资料迁移',
      created_at: '2024-11-01T09:00:00',
    },
    {
      id: 2,
      case_id: 102,
      from_court_id: 2,
      to_court_id: 3,
      transferred_by: 1002,
      transfer_date: '2024-11-05T14:00:00',
      reason: '案件重审',
      created_at: '2024-11-05T13:00:00',
    },
  ];
};

export const deleteCaseTransfer = async (id: number): Promise<void> => {
  // 模拟删除操作
  return new Promise((resolve) => setTimeout(resolve, 500));
};
