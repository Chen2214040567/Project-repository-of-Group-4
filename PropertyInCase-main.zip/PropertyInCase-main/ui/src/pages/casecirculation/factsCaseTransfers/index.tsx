import React from 'react';
import CaseTransferTable from './components/CaseTransferTable';

const CaseTransferPage: React.FC = () => {
  return (
    <div style={{ backgroundColor: '#f0f2f5', padding: '10px' }}>
      <CaseTransferTable />
    </div>
  )
};

export default CaseTransferPage;
