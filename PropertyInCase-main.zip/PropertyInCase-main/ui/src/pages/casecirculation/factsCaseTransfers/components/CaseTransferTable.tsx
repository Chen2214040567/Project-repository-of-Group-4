import {
  DeleteOutlined,
  EditOutlined,
  PlusOutlined,
  ReloadOutlined,
  SearchOutlined,
  SyncOutlined,
} from '@ant-design/icons';
import { Button, Card, Col, Input, message, Popconfirm, Row, Space, Table } from 'antd';
import React, { useEffect, useState } from 'react';
import { deleteCaseTransfer, fetchCaseTransfers } from '../service';
import { CaseTransfer, SearchParams } from '../types';
import CaseTransferModal from './CaseTransferModal';

const CaseTransferTable: React.FC = () => {
  const [data, setData] = useState<CaseTransfer[]>([]);
  const [filteredData, setFilteredData] = useState<CaseTransfer[]>([]);
  const [searchParams, setSearchParams] = useState<SearchParams>({
    case_id: '',
    from_court_id: '',
    to_court_id: '',
  });
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [editingRecord, setEditingRecord] = useState<CaseTransfer | null>(null);

  useEffect(() => {
    // 模拟获取数据
    fetchCaseTransfers().then((result) => {
      setData(result);
      setFilteredData(result); // 确保在数据获取后再设置 filteredData
    });
    handleRefresh(); // 页面加载时自动刷新数据
  }, []);

  const handleDelete = async (id: number) => {
    await deleteCaseTransfer(id);
    const newData = data.filter((item) => item.id !== id);
    setData(newData);
    setFilteredData(newData);
    message.success('删除成功');
  };

  const showModal = (record?: CaseTransfer) => {
    setEditingRecord(record || null);
    setIsModalVisible(true);
  };

  const handleSearch = () => {
    const filtered = data.filter((item) => {
      return (
        (searchParams.case_id ? item.case_id.toString().includes(searchParams.case_id) : true) &&
        (searchParams.from_court_id
          ? item.from_court_id.toString().includes(searchParams.from_court_id)
          : true) &&
        (searchParams.to_court_id
          ? item.to_court_id.toString().includes(searchParams.to_court_id)
          : true)
      );
    });
    setFilteredData(filtered);
  };

  // 重置搜索框内容和表格数据
  const handleReset = () => {
    setSearchParams({
      case_id: '',
      from_court_id: '',
      to_court_id: '',
    });
    setFilteredData(data);
    message.success('搜索条件已重置');
  };

  // 重新从服务器获取数据
  const handleRefresh = async () => {
    try {
      const result = await fetchCaseTransfers();
      setData(result);
      setFilteredData(result);
      message.success('数据已刷新');
    } catch (error) {
      message.error('刷新失败，请重试');
    }
  };

  const columns = [
    {
      title: '流转ID',
      dataIndex: 'id',
      key: 'id',
      sorter: (a: CaseTransfer, b: CaseTransfer) => a.id - b.id,
    },
    {
      title: '案件ID',
      dataIndex: 'case_id',
      key: 'case_id',
      sorter: (a: CaseTransfer, b: CaseTransfer) => a.case_id - b.case_id,
    },
    { title: '原法院ID', dataIndex: 'from_court_id', key: 'from_court_id' },
    { title: '目标法院ID', dataIndex: 'to_court_id', key: 'to_court_id' },
    { title: '操作人ID', dataIndex: 'transferred_by', key: 'transferred_by' },
    {
      title: '流转时间',
      dataIndex: 'transfer_date',
      key: 'transfer_date',
      render: (text: string) => {
        const date = new Date(text); // 转换为原生 Date 对象
        return date.toLocaleString(); // 使用 toLocaleString 格式化日期
      },
    },
    { title: '流转原因', dataIndex: 'reason', key: 'reason' },
    {
      title: '操作',
      key: 'action',
      render: (_: string, record: CaseTransfer) => (
        <Space>
          <Button type="link" onClick={() => showModal(record)} icon={<EditOutlined />}>
            编辑
          </Button>
          <Popconfirm title="确认删除?" onConfirm={() => handleDelete(record.id)}>
            <Button type="link" danger icon={<DeleteOutlined />}>
              删除
            </Button>
          </Popconfirm>
        </Space>
      ),
    },
  ];

  return (
    <>
      <Card title="案件流转历史" style={{ marginTop: 5 }}>
        <Row gutter={16}>
          <Col span={4}>
            <Input
              placeholder="案件ID"
              value={searchParams.case_id}
              onChange={(e) => setSearchParams({ ...searchParams, case_id: e.target.value })}
            />
          </Col>
          <Col span={4}>
            <Input
              placeholder="原法院ID"
              value={searchParams.from_court_id}
              onChange={(e) => setSearchParams({ ...searchParams, from_court_id: e.target.value })}
            />
          </Col>
          <Col span={4}>
            <Input
              placeholder="目标法院ID"
              value={searchParams.to_court_id}
              onChange={(e) => setSearchParams({ ...searchParams, to_court_id: e.target.value })}
            />
          </Col>
          <Col span={6}>
            <Button type="primary" onClick={handleSearch} icon={<SearchOutlined />}>
              搜索
            </Button>
            &nbsp;
            <Button type="primary" onClick={() => showModal()} icon={<PlusOutlined />}>
              新增
            </Button>
            &nbsp;
            <Button type="default" onClick={handleReset} icon={<ReloadOutlined />}>
              重置
            </Button>
            &nbsp;
            <Button type="default" onClick={handleRefresh} icon={<SyncOutlined />}>
              刷新
            </Button>
          </Col>
        </Row>
      </Card>
      <Card title="案件流转列表" style={{ marginTop: 10 }}>
        <Table
          rowKey="id"
          columns={columns}
          dataSource={filteredData} // 应该绑定到您的表格数据
          pagination={{
            pageSize: 5,
            showSizeChanger: true,
            pageSizeOptions: ['5', '10', '20'],
          }}
          bordered
          style={{ marginTop: 16 }}
        />

        <CaseTransferModal
          visible={isModalVisible}
          record={editingRecord}
          onCancel={() => setIsModalVisible(false)}
          onSave={(newRecord) => {
            const updatedData = editingRecord
              ? data.map((item) => (item.id === editingRecord.id ? newRecord : item))
              : [...data, newRecord];
            setData(updatedData);
            setFilteredData(updatedData);
            setIsModalVisible(false);
          }}
        />
      </Card>
    </>
  );
};

export default CaseTransferTable;
