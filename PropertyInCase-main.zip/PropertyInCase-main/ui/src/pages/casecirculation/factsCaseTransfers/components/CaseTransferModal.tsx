import { DatePicker, Form, Input, Modal } from 'antd';
import React, { useEffect } from 'react';
import { CaseTransfer } from '../types';

interface Props {
  visible: boolean;
  record?: CaseTransfer | null;
  onCancel: () => void;
  onSave: (record: CaseTransfer) => void;
}

const CaseTransferModal: React.FC<Props> = ({ visible, record, onCancel, onSave }) => {
  const [form] = Form.useForm();

  useEffect(() => {
    if (record) {
      // 处理 record 中的日期格式化，去除 moment
      form.setFieldsValue({
        ...record,
        transfer_date: record.transfer_date ? new Date(record.transfer_date) : new Date(),
      });
    } else {
      form.resetFields();
    }
  }, [form, record]);

  const handleOk = async () => {
    const values = await form.validateFields();
    const newRecord: CaseTransfer = {
      ...record,
      ...values,
      transfer_date: values.transfer_date
        ? values.transfer_date.toISOString()
        : new Date().toISOString(),
      created_at: record ? record.created_at : new Date().toISOString(),
    };
    onSave(newRecord);
  };

  return (
    <Modal
      title={record ? '编辑流转记录' : '新增流转记录'}
      visible={visible}
      onOk={handleOk}
      onCancel={onCancel}
    >
      <Form
        form={form}
        layout="vertical"
        initialValues={
          record
            ? { ...record, transfer_date: new Date(record.transfer_date) }
            : { transfer_date: new Date() }
        }
      >
        <Form.Item name="id" label="流转ID" rules={[{ required: true, message: '请输入流转ID' }]}>
          <Input disabled={!!record} />
        </Form.Item>
        <Form.Item
          name="case_id"
          label="案件ID"
          rules={[{ required: true, message: '请输入案件ID' }]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="from_court_id"
          label="原法院ID"
          rules={[{ required: true, message: '请输入原法院ID' }]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="to_court_id"
          label="目标法院ID"
          rules={[{ required: true, message: '请输入目标法院ID' }]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="transferred_by"
          label="操作人ID"
          rules={[{ required: true, message: '请输入操作人ID' }]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="transfer_date"
          label="流转时间"
          rules={[{ required: true, message: '请输入流转时间' }]}
        >
          <DatePicker
            showTime
            style={{ width: '100%' }}
            format="YYYY-MM-DD HH:mm:ss"
            onChange={(date) => form.setFieldsValue({ transfer_date: date })}
          />
        </Form.Item>
        <Form.Item
          name="reason"
          label="流转原因"
          rules={[{ required: true, message: '请输入流转原因' }]}
        >
          <Input.TextArea rows={4} />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default CaseTransferModal;
