import React, { useEffect, useState } from 'react';
import { Button, Table, Input, Modal, message, Row, Col } from 'antd';
import { ColumnsType } from 'antd/es/table';
import { Court } from './types';
import { fetchCourtsData, deleteCourtData, addCourtData, updateCourtData } from './service';
import CourtForm from './components/CourtForm';

const CourtPage: React.FC = () => {
  const [courts, setCourts] = useState<Court[]>([]); // Store all courts data
  const [filteredCourts, setFilteredCourts] = useState<Court[]>([]); // Store filtered courts data
  const [isModalVisible, setIsModalVisible] = useState(false); // Modal visibility state
  const [editingCourt, setEditingCourt] = useState<Court | null>(null); // Court being edited
  const [loading, setLoading] = useState(false); // Loading state for async operations
  const [searchQuery, setSearchQuery] = useState<string>(''); // Search query for filtering courts

  // Fetch courts data on page load
  useEffect(() => {
    const loadCourts = async () => {
      setLoading(true);
      try {
        const data = await fetchCourtsData();
        setCourts(data);
        setFilteredCourts(data); // Set filtered courts initially
      } catch (error: any) {
        message.error(`加载法院列表失败: ${error.message}`);
      } finally {
        setLoading(false);
      }
    };
    loadCourts();
  }, []);

  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  // Filter courts based on search query
  const filterCourts = (query: string) => {
    if (!query) {
      setFilteredCourts(courts); // Show all courts if no query
    } else {
      const filtered = courts.filter(
        (court) =>
          court.name.toLowerCase().includes(query.toLowerCase()) ||
          court.address.toLowerCase().includes(query.toLowerCase()) ||
          court.contact_number.includes(query)
      );
      setFilteredCourts(filtered);
    }
  };

  // Check if a court with the same name, address, and contact number already exists
  const isDuplicateCourt = (court: Court): boolean => {
    return courts.some(
      (existingCourt) =>
        existingCourt.name === court.name &&
        existingCourt.address === court.address &&
        existingCourt.contact_number === court.contact_number
    );
  };

  // Handle save (add or update) court
  const handleSave = async (values: Court) => {
    setLoading(true);
    try {
      // Check if the new or updated court is a duplicate
      if (isDuplicateCourt(values)) {
        message.error('法院信息已存在，不能重复添加');
        return; // Prevent saving if it's a duplicate
      }

      if (editingCourt) {
        // Update existing court
        const updatedCourt = { ...editingCourt, ...values };
        await updateCourtData(updatedCourt); // Update via service
        const updatedCourts = courts.map(court => court.id === editingCourt.id ? updatedCourt : court);
        setCourts(updatedCourts);
        setFilteredCourts(updatedCourts);
        message.success('法院更新成功');
      } else {
        // Add new court
        const newCourt = await addCourtData(values); // Add via service
        setCourts([...courts, newCourt]);
        setFilteredCourts([...courts, newCourt]);
        message.success('法院添加成功');
      }
      
      // Close modal after save
      setIsModalVisible(false);
      setEditingCourt(null); // Reset editingCourt after save
    } catch (error: any) {
      message.error(`操作失败: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Handle edit button click
  const handleEdit = (court: Court) => {
    setEditingCourt(court);
    setIsModalVisible(true);
  };

  // Handle delete button click
  const handleDelete = async (id: number) => {
    setLoading(true);
    try {
      await deleteCourtData(id); // Call service to delete court
      const updatedCourts = courts.filter(court => court.id !== id);
      setCourts(updatedCourts);
      setFilteredCourts(updatedCourts);
      message.success('法院删除成功');
    } catch (error: any) {
      message.error(`删除失败: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Table columns configuration
  const columns: ColumnsType<Court> = [
    {
      title: '法院名称',
      dataIndex: 'name',
    },
    {
      title: '法院地址',
      dataIndex: 'address',
    },
    {
      title: '联系电话',
      dataIndex: 'contact_number',
    },
    {
      title: '操作',
      key: 'action',
      render: (_, record) => (
        <>
          <Button type="link" onClick={() => handleEdit(record)}>编辑</Button>
          <Button type="link" danger onClick={() => handleDelete(record.id)}>删除</Button>
        </>
      ),
    },
  ];

  return (
    <div>
      <Row gutter={16} style={{ marginBottom: 16 }} justify="start">
        <Col>
          <Input
            placeholder="搜索法院"
            value={searchQuery}
            onChange={handleSearchChange}
            onKeyDown={(e) => e.key === 'Enter' && filterCourts(searchQuery)}
            style={{ width: '200px' }}
          />
        </Col>
        <Col>
          <Button type="primary" onClick={() => filterCourts(searchQuery)} style={{ marginLeft: 8 }}>
            查询
          </Button>
        </Col>
        <Col>
          <Button
            type="primary"
            onClick={() => setIsModalVisible(true)}
            style={{ marginLeft: 8 }}
          >
            新增法院
          </Button>
        </Col>
      </Row>

      <Table
        rowKey="id"
        columns={columns}
        dataSource={filteredCourts}
        loading={loading}
        pagination={false}
        style={{ marginTop: 16 }}
      />

      <Modal
        title={editingCourt ? '编辑法院' : '新增法院'}
        visible={isModalVisible}
        onCancel={() => {
          setIsModalVisible(false);
          setEditingCourt(null); // Reset editingCourt when modal is closed
        }}
        footer={null}
      >
        <CourtForm
          initialValues={editingCourt || {}}
          onFinish={handleSave}
          onCancel={() => {
            setIsModalVisible(false);
            setEditingCourt(null); // Reset onCancel
          }}
        />
      </Modal>
    </div>
  );
};

export default CourtPage;
