

import React, { useEffect } from 'react';
import { Form, Input, Button } from 'antd';
import { Court } from '../types';

interface CourtFormProps {
  initialValues: Court;
  onFinish: (values: Court) => void;
  onCancel: () => void;
}

const CourtForm: React.FC<CourtFormProps> = ({ initialValues, onFinish, onCancel }) => {
  const [form] = Form.useForm();

  useEffect(() => {
    form.setFieldsValue(initialValues); // Populate form with initial values
  }, [initialValues]);

  return (
    <Form form={form} name="courtForm" onFinish={onFinish} layout="vertical">
      <Form.Item label="法院名称" name="name" rules={[{ required: true, message: '请输入法院名称' }]}>
        <Input />
      </Form.Item>

      <Form.Item label="法院地址" name="address" rules={[{ required: true, message: '请输入法院地址' }]}>
        <Input />
      </Form.Item>

      <Form.Item label="联系电话" name="contact_number" rules={[{ required: true, message: '请输入联系电话' }]}>
        <Input />
      </Form.Item>

      <div style={{ textAlign: 'right' }}>
        <Button onClick={onCancel} style={{ marginRight: 8 }}>
          取消
        </Button>
        <Button type="primary" htmlType="submit">
          提交
        </Button>
      </div>
    </Form>
  );
};

export default CourtForm;
