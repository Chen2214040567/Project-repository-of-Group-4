

export interface Court {
    id: number;
    name: string;
    address: string;
    contact_number: string;
    created_at: string;
    updated_at: string;
  }
  