

import { Court } from './types';

// Simulate an API call to fetch courts data
export const fetchCourtsData = async (): Promise<Court[]> => {
  // Simulate an API response
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        { id: 1, name: '北京市法院', address: '北京市', contact_number: '010-12345678' },
        { id: 2, name: '上海市法院', address: '上海市', contact_number: '021-87654321' },
        { id: 3, name: '广州市法院', address: '广州市', contact_number: '020-23456789' },
      ]);
    }, 1000);
  });
};

export const deleteCourtData = async (id: number): Promise<void> => {
  // Simulate an API delete
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve();
    }, 1000);
  });
};

export const addCourtData = async (court: Court): Promise<Court> => {
  // Simulate an API add
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ ...court, id: Date.now() }); // Mock new ID
    }, 1000);
  });
};

export const updateCourtData = async (court: Court): Promise<Court> => {
  // Simulate an API update
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(court);
    }, 1000);
  });
};
