import { createStyles } from 'antd-style';

const useStyles = createStyles(() => {
  return {};
});
export default useStyles;
