

const test2 = ()=>{
  return(
    <>
    <h1>test2</h1>
    </>
  )
}
export default test2
