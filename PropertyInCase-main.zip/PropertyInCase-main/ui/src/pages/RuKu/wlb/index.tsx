import React, { useState, useEffect } from 'react';
import { Button, Form, Input, Modal, message, Popconfirm } from 'antd';
import ProTable, { ProColumns } from '@ant-design/pro-table';
import { PlusOutlined } from '@ant-design/icons';
import axios from 'axios';

// 物料数据接口
interface Material {
  id: number;
  name: string;
  sku_code: string;
  category: string;
  description: string;
  unit: string;
  created_at: string;
  updated_at: string;
}

const MaterialList: React.FC = () => {
  const [modalVisible, setModalVisible] = useState(false); // 控制添加/编辑弹窗
  const [editingMaterial, setEditingMaterial] = useState<Material | null>(null); // 当前编辑的物料
  const [form] = Form.useForm(); // Ant Design 表单

  // 获取物料列表
  const fetchMaterials = async (params: any) => {
    const response = await axios.get('/api/materials', { params });
    return {
      data: response.data.items,
      total: response.data.total,
      success: true,
    };
  };

  // 添加物料
  const handleCreate = async (values: any) => {
    try {
      await axios.post('/api/materials', values);
      message.success('物料创建成功');
      setModalVisible(false);
      form.resetFields();
    } catch (error) {
      message.error('物料创建失败');
    }
  };

  // 编辑物料
  const handleEdit = async (values: any) => {
    if (editingMaterial) {
      try {
        await axios.put(`/api/materials/${editingMaterial.id}`, values);
        message.success('物料更新成功');
        setModalVisible(false);
        form.resetFields();
      } catch (error) {
        message.error('物料更新失败');
      }
    }
  };

  // 删除物料
  const handleDelete = async (id: number) => {
    try {
      await axios.delete(`/api/materials/${id}`);
      message.success('物料删除成功');
    } catch (error) {
      message.error('物料删除失败');
    }
  };

  // 表格列定义
  const columns: ProColumns<Material>[] = [
    { title: '物料名称', dataIndex: 'name' },
    { title: '物料编号', dataIndex: 'sku_code' },
    { title: '物料类别', dataIndex: 'category' },
    { title: '物料描述', dataIndex: 'description' },
    { title: '计量单位', dataIndex: 'unit' },
    {
      title: '操作',
      dataIndex: 'action',
      render: (_, record) => (
        <>
          <Button
            type="link"
            onClick={() => {
              setEditingMaterial(record);
              form.setFieldsValue(record);
              setModalVisible(true);
            }}
          >
            编辑
          </Button>
          <Popconfirm
            title="确认删除该物料?"
            onConfirm={() => handleDelete(record.id)}
            okText="确认"
            cancelText="取消"
          >
            <Button type="link" danger>
              删除
            </Button>
          </Popconfirm>
        </>
      ),
    },
  ];

  // 渲染表格
  return (
    <>
      <ProTable<Material>
        headerTitle="物料列表"
        actionRef={null}
        rowKey="id"
        columns={columns}
        request={fetchMaterials}
        toolBarRender={() => [
          <Button
            key="primary"
            type="primary"
            icon={<PlusOutlined />}
            onClick={() => {
              setEditingMaterial(null);
              form.resetFields();
              setModalVisible(true);
            }}
          >
            新增物料
          </Button>,
        ]}
      />
      
      <Modal
        visible={modalVisible}
        title={editingMaterial ? '编辑物料' : '新增物料'}
        onCancel={() => setModalVisible(false)}
        footer={null}
        destroyOnClose
      >
        <Form
          form={form}
          onFinish={editingMaterial ? handleEdit : handleCreate}
          initialValues={editingMaterial || {}}
        >
          <Form.Item
            label="物料名称"
            name="name"
            rules={[{ required: true, message: '请输入物料名称' }]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            label="物料编号"
            name="sku_code"
            rules={[{ required: true, message: '请输入物料编号' }]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            label="物料类别"
            name="category"
            rules={[{ required: true, message: '请输入物料类别' }]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            label="物料描述"
            name="description"
            rules={[{ required: true, message: '请输入物料描述' }]}
          >
            <Input.TextArea />
          </Form.Item>
          <Form.Item
            label="计量单位"
            name="unit"
            rules={[{ required: true, message: '请输入计量单位' }]}
          >
            <Input />
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit" block>
              {editingMaterial ? '保存' : '创建'}
            </Button>
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};

export default MaterialList;
