

const test1 = ()=>{
  return(
    <>
    <h1>test2</h1>
    </>
  )
}


export default test1
