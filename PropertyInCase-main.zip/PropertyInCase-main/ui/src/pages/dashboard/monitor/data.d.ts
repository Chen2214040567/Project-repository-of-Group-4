export type TagType = {
  name: string;
  value: number;
  type: string;
};
