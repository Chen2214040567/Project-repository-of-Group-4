import { defineModel } from 'umi';

export default defineModel({
  namespace: 'dictionaryCategories',
  state: {},
  effects: {},
  reducers: {},
});
