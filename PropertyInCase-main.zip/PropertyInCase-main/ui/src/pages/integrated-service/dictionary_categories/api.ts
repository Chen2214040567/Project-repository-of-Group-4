import { request } from 'umi'; // 假设使用 umi 进行请求

export const fetchDictionaryCategories = async () => {
  const response = await fetch('/api/dictionary_categories'); // 请替换为实际API地址
  if (!response.ok) {
      throw new Error('Network response was not ok');
  }
  return await response.json();
};

export const deleteDictionaryCategory = async (id: number) => {
  const response = await fetch(`/api/dictionary_categories/${id}`, {
      method: 'DELETE',
  });
  if (!response.ok) {
      throw new Error('Network response was not ok');
  }
};


// 获取字典分类列表
export const getCategories = async () => {
  return request('/api/dictionary_categories', {
    method: 'GET',
  });
};

// 新建字典分类
export const createCategory = async (category: { id: number; name: string; description: string }) => {
  return request('/api/dictionary_categories', {
    method: 'POST',
    data: category,
  });
};

// 编辑字典分类
export const updateCategory = async (category: { id: number; name: string; description: string }) => {
  return request(`/api/dictionary_categories/${category.id}`, {
    method: 'PUT',
    data: category,
  });
};

// 删除字典分类
export const deleteCategory = async (id: number) => {
  return request(`/api/dictionary_categories/${id}`, {
    method: 'DELETE',
  });
};
