import React, { useState, useEffect } from 'react';
import { ProTable } from '@ant-design/pro-components';
import { PlusOutlined, DeleteOutlined, EditOutlined } from '@ant-design/icons';
import { history, Link } from 'umi';
import { Table, Button, Modal, Form, Input, message } from 'antd';
import { fetchDictionaryCategories, deleteDictionaryCategory } from './api';
import { getCategories, createCategory, updateCategory, deleteCategory } from './api';
import { DictionaryCategoryType } from './types';

const DictionaryCategories: React.FC = () => {
    const [dataSource, setDataSource] = useState<DictionaryCategoryType[]>([]);
    const [loading, setLoading] = useState<boolean>(false);
    const [data, setData] = useState<DictionaryCategoryType[]>([]);
    const [editingCategory, setEditingCategory] = useState<DictionaryCategoryType | null>(null);
    const [isModalVisible, setIsModalVisible] = useState(false);

    // 获取字典分类列表
    const fetchCategories = async () => {
      const result = await getCategories();
      if (result.success) {
        setData(result.data);
      } else {
        message.error('获取字典分类失败');
      }
    };

    // 新建或编辑字典分类
    const handleOk = async (values: DictionaryCategoryType) => {
      if (editingCategory) {
        // 编辑
        const result = await updateCategory(values);
        if (result.success) {
          message.success('更新成功');
          setIsModalVisible(false);
          fetchCategories();
        } else {
          message.error('更新失败');
        }
      } else {
        // 新建
        const result = await createCategory(values);
        if (result.success) {
          message.success('创建成功');
          setIsModalVisible(false);
          fetchCategories();
        } else {
          message.error('创建失败');
        }
      }
    };

    // 删除字典分类
    const handleDelete = async (id: number) => {
      const result = await deleteCategory(id);
      if (result.success) {
        message.success('删除成功');
        fetchCategories();
      } else {
        message.error('删除失败');
      }
    };

    useEffect(() => {
        setLoading(true);
        fetchDictionaryCategories().then(response => {
            setDataSource(response);
            setLoading(false);
        }).catch(() => {
            setLoading(false);
        });
    }, []);

    const columns = [
        {
            title: '分类ID',
            dataIndex: 'id',
            key: 'id',
            valueType: 'number',
            sorter: (a, b) => a.id - b.id,
        },
        {
            title: '分类名称',
            dataIndex: 'name',
            key: 'name',
            sorter: (a, b) => a.name.localeCompare(b.name),
        },
        {
            title: '分类描述',
            dataIndex: 'description',
            key: 'description',
            ellipsis: true,
        },
        {
            title: '操作',
            dataIndex: 'action',
            key: 'action',
            valueType: 'option',
            render: (_: any, record: DictionaryCategoryType) => [
                <Link to={`/integrated-service/dictionary_categories/edit/${record.id}`} key="edit">
                    <EditOutlined /> 编辑
                </Link>,
                <a href="javascript:;" key="delete" onClick={() => handleDelete(record.id)}>
                    <DeleteOutlined /> 删除
                </a>,
            ],
        },
    ];

    return (
        <ProTable<DictionaryCategoryType>
            columns={columns}
            request={(params, sorter, filter) => ({
                ...params,
                sorter: sorter.map(item => ({
                    ...item,
                    field: item.field === 'action' ? undefined : item.field,
                })),
            })}
            rowKey="id"
            toolBarRender={() => [

          <div>
          <div style={{ marginBottom: 6}}>
            <Button
              type="primary"
              icon={<PlusOutlined />}
              onClick={() => {
                setEditingCategory(null);
                setIsModalVisible(true);
              }}
            >
              新建分类
            </Button>

          </div>

          <Modal
            title={editingCategory ? '编辑字典分类' : '新建字典分类'}
            visible={isModalVisible}
            onCancel={() => setIsModalVisible(false)}
            footer={null}
          >
            <Form
              initialValues={editingCategory || { name: '', description: '' }}
              onFinish={handleOk}
            >

              <Form.Item
                label="分类ID"
                name="name"
                rules={[{ required: true, message: '请输入分类ID' }]}
              >
                <Input />
              </Form.Item>


              <Form.Item
                label="分类名称"
                name="name"
                rules={[{ required: true, message: '请输入分类名称' }]}
              >
                <Input />
              </Form.Item>

              <Form.Item label="分类描述" name="description">
                <Input.TextArea />
              </Form.Item>

              <Form.Item>
                <Button type="primary" htmlType="submit">
                  提交
                </Button>
              </Form.Item>

            </Form>
          </Modal>

          </div>

            ]}
            dataSource={dataSource}
            loading={loading}
            pagination={{ pageSize: 10 }}
            dateFormatter="string"
        />
    );

};

export default DictionaryCategories;
