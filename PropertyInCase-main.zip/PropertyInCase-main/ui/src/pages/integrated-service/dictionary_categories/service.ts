import axios from 'axios';

const API_URL = '/api/dictionary_categories'; // 请替换为实际API地址

export const DictionaryCategoriesService = {
  fetchList: async () => {
    const response = await axios.get(API_URL);
    return response.data;
  },
  deleteById: async (id: number) => {
    await axios.delete(`${API_URL}/${id}`);
  },
  // 可根据需要添加其他方法，如 create 和 update
};
