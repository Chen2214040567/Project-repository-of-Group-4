const Newbuilt = ()=>{

  return (
      <h2>测试“新建综合业务”页成功</h2>
  )
}

export default Newbuilt
