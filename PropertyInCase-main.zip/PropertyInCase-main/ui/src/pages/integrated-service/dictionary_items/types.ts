export interface DictionaryItemType {
  id: number;
  category_id: number;
  key: string;
  value: string;
  description: string;
  createdAt: string;
  updatedAt: string;
}

export interface DictionaryCategoryType {
  id: number;
  name: string;
  description: string;
  created_at: string;
  updated_at: string;
}
