import { request } from 'umi'; // 假设使用 umi 进行请求

export const fetchDictionaryItems = async () => {
  const response = await fetch('/api/dictionary_items'); // 请替换为实际API地址
  if (!response.ok) {
      throw new Error('Network response was not ok');
  }
  return await response.json();
};

export const deleteDictionaryItems = async (id: number) => {
  const response = await fetch(`/api/dictionary_items/${id}`, {
      method: 'DELETE',
  });
  if (!response.ok) {
      throw new Error('Network response was not ok');
  }
};

// 获取字典项列表
export const getItems = async () => {
  return request('/api/dictionary_items', {
    method: 'GET',
  });
};

// 新建字典项
export const createItem = async (item: { key: string; value: string; description: string; category_id: number }) => {
  return request('/api/dictionary_items', {
    method: 'POST',
    data: item,
  });
};

// 编辑字典项
export const updateItem = async (item: { id: number; key: string; value: string; description: string; category_id: number }) => {
  return request(`/api/dictionary_items/${item.id}`, {
    method: 'PUT',
    data: item,
  });
};

// 删除字典项
export const deleteItem = async (id: number) => {
  return request(`/api/dictionary_items/${id}`, {
    method: 'DELETE',
  });
};

// 获取字典分类列表
export const getCategories = async () => {
  return request('/api/dictionary_categories', {
    method: 'GET',
  });
};
