import React, { useState, useEffect } from 'react';
import { ProTable } from '@ant-design/pro-components';
import { PlusOutlined, DeleteOutlined, EditOutlined } from '@ant-design/icons';
import { history, Link } from 'umi';
import { Table, Button, Modal, Form, Input, Select, message } from 'antd';
import { fetchDictionaryItems, deleteDictionaryItems } from './api';
import { getItems, createItem, updateItem, deleteItem, getCategories } from './api';
import { DictionaryItemType, DictionaryCategoryType } from './types';

const { Option } = Select;

const DictionaryItems: React.FC = () => {
    const [dataSource, setDataSource] = useState<DictionaryItemType[]>([]);
    const [loading, setLoading] = useState<boolean>(false);
    const [data, setData] = useState<DictionaryItemType[]>([]);
    const [editingItem, setEditingItem] = useState<DictionaryItemType | null>(null);
    const [categories, setCategories] = useState<DictionaryCategoryType[]>([]);
    const [isModalVisible, setIsModalVisible] = useState(false);

    // 获取字典项列表
    const fetchItems = async () => {
      const result = await getItems();
      if (result.success) {
        setData(result.data);
      } else {
        message.error('获取字典项失败');
      }
    };

    // 获取字典分类列表
    const fetchCategories = async () => {
      const result = await getCategories();
      if (result.success) {
        setCategories(result.data);
      } else {
        message.error('获取分类失败');
      }
    };

    // 新建或编辑字典项
    const handleOk = async (values: DictionaryItemType) => {
      if (editingItem) {
        // 编辑
        const result = await updateItem(values);
        if (result.success) {
          message.success('更新成功');
          setIsModalVisible(false);
          fetchItems();
        } else {
          message.error('更新失败');
        }
      } else {
        // 新建
        const result = await createItem(values);
        if (result.success) {
          message.success('创建成功');
          setIsModalVisible(false);
          fetchItems();
        } else {
          message.error('创建失败');
        }
      }
    };

    // 删除字典项
    const handleDelete = async (id: number) => {
      const result = await deleteItem(id);
      if (result.success) {
        message.success('删除成功');
        fetchItems();
      } else {
        message.error('删除失败');
      }
    };

    useEffect(() => {
      setLoading(true);
      fetchDictionaryItems().then(response => {
        setDataSource(response);
        setLoading(false);
      }).catch(() => {
        setLoading(false);
      });
    }, []);

    const columns = [
      {
        title: '字典项ID',
        dataIndex: 'id',
        key: 'id',
        valueType: 'number',
        sorter: (a, b) => a.id - b.id,
      },
      {
        title: '分类ID',
        dataIndex: 'category_id',
        key: 'category_id',
        valueType: 'number',
        sorter: (a, b) => a.category_id - b.category_id,
      },
      {
        title: '字典项键',
        dataIndex: 'key',
        key: 'key',
        sorter: (a, b) => a.key.localeCompare(b.key),
      },
      {
        title: '字典项值',
        dataIndex: 'value',
        key: 'value',
        ellipsis: true,
      },
      {
        title: '描述',
        dataIndex: 'description',
        key: 'description',
        ellipsis: true,
      },
      {
        title: '操作',
        dataIndex: 'action',
        key: 'action',
        valueType: 'option',
        render: (_: any, record: DictionaryItemType) => [
          <Link to={`/integrated-service/dictionary_items/edit/${record.id}`} key="edit">
            <EditOutlined /> 编辑
          </Link>,
          <a href="javascript:;" key="delete" onClick={() => handleDelete(record.id)}>
            <DeleteOutlined /> 删除
          </a>,
        ],
      },
    ];

    return (
      <ProTable<DictionaryItemType>
        columns={columns}
        request={(params, sorter, filter) => ({
          ...params,
          sorter: sorter.map(item => ({
            ...item,
            field: item.field === 'action' ? undefined : item.field,
          })),
        })}
        rowKey="id"
        toolBarRender={() => [

        <div>
          <div style={{ marginBottom: 6 }}>

            <Button
              type="primary"
              icon={<PlusOutlined />}
              onClick={() => {
                setEditingItem(null);
                setIsModalVisible(true);
              }}
            >
              新建字典项
            </Button>

          </div>

          <Modal
            title={editingItem ? '编辑字典项' : '新建字典项'}
            visible={isModalVisible}
            onCancel={() => setIsModalVisible(false)}
            footer={null}
          >
            <Form
              initialValues={editingItem || { key: '', value: '', description: '', category_id: undefined }}
              onFinish={handleOk}
            >
              <Form.Item
                label="字典项键"
                name="key"
                rules={[{ required: true, message: '请输入字典项键' }]}
              >
                <Input />
              </Form.Item>

              <Form.Item
                label="字典项值"
                name="value"
                rules={[{ required: true, message: '请输入字典项值' }]}
              >
                <Input />
              </Form.Item>

              <Form.Item label="字典项描述" name="description">
                <Input.TextArea />
              </Form.Item>

              <Form.Item
                label="字典分类"
                name="category_id"
                rules={[{ required: true, message: '请选择字典分类' }]}
              >
                <Select>
                  {categories.map(category => (
                    <Option key={category.id} value={category.id}>
                      {category.name}
                    </Option>
                  ))}
                </Select>
              </Form.Item>

              <Form.Item>
                <Button type="primary" htmlType="submit">
                  提交
                </Button>
              </Form.Item>
            </Form>

          </Modal>
        </div>

        ]}

        dataSource={dataSource}
        loading={loading}
        pagination={{ pageSize: 10 }}
        dateFormatter="string"
      />
    );
};

export default DictionaryItems;
