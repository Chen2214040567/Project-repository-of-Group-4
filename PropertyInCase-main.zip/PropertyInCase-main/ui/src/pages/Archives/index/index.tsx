﻿// src/pages/file-management/index.tsx
import React, { useState } from 'react';
import FileForm from './FileForm';

const PAGE_SIZE = 5; // 每页显示的档案数量

const FileManagement: React.FC = () => {
    const [files, setFiles] = useState<any[]>([]);
    const [currentPage, setCurrentPage] = useState(1);

    const addFile = (newFile: any) => {
        setFiles([...files, newFile]);
    };

    const deleteFile = (id: number) => {
        setFiles(files.filter(file => file.id !== id));
    };

    const totalPages = Math.ceil(files.length / PAGE_SIZE);
    const currentFiles = files.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

    const handleNextPage = () => {
        if (currentPage < totalPages) {
            setCurrentPage(currentPage + 1);
        }
    };

    const handlePrevPage = () => {
        if (currentPage > 1) {
            setCurrentPage(currentPage - 1);
        }
    };

    return (
        <div>
            <h1>档案管理</h1>
            <FileForm onSubmit={addFile} initialFile={null} />
            <ul>
                {currentFiles.map(file => (
                    <li key={file.id}>
                        <strong>文件名:</strong> {file.name}<br />
                        <strong>描述:</strong> {file.description}<br />
                        <strong>类型:</strong> {file.type}
                        <button type="button" onClick={() => deleteFile(file.id)}>删除</button>
                    </li>
                ))}
            </ul>
            <div>
                <button type="button" onClick={handlePrevPage} disabled={currentPage === 1}>
                    上一页
                </button>
                <span> 第 {currentPage} 页 / {totalPages} 页 </span>
                <button type="button" onClick={handleNextPage} disabled={currentPage === totalPages}>
                    下一页
                </button>
            </div>
        </div>
    );
};

export default FileManagement;
