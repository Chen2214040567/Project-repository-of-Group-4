﻿import React, { useEffect, useState } from 'react';

interface FileFormProps {
    onSubmit: (file: any) => void;
    initialFile: any | null;
}

const FileForm: React.FC<FileFormProps> = ({ onSubmit, initialFile }) => {
    const [file, setFile] = useState({ id: null, name: '', description: '', type: '', fileData: null });

    useEffect(() => {
        if (initialFile) {
            setFile(initialFile);
        } else {
            setFile({ id: null, name: '', description: '', type: '', fileData: null });
        }
    }, [initialFile]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (file.name.trim() === '') {
            alert("文件名不能为空");
            return;
        }
        onSubmit({ ...file, id: file.id || Date.now() });
        resetForm();
    };

    const resetForm = () => {
        setFile({ id: null, name: '', description: '', type: '', fileData: null });
    };

    const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const uploadedFile = e.target.files[0];
            setFile({ ...file, fileData: uploadedFile });
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <label>
                文件名:
                <input
                    type="text"
                    value={file.name}
                    onChange={(e) => setFile({ ...file, name: e.target.value })}
                    required
                />
            </label>
            <label>
                描述:
                <textarea
                    value={file.description}
                    onChange={(e) => setFile({ ...file, description: e.target.value })}
                    maxLength={200}
                />
            </label>
            <label>
                类型:
                <select
                    value={file.type}
                    onChange={(e) => setFile({ ...file, type: e.target.value })}
                >
                    <option value="">选择文件类型</option>
                    <option value="text">文本</option>
                    <option value="image">图片</option>
                    <option value="pdf">PDF</option>
                    <option value="other">其他</option>
                </select>
            </label>
            <label>
                上传文件:
                <input type="file" onChange={handleFileUpload} />
            </label>
            <button type="submit">保存档案</button>
            <button type="button" onClick={resetForm}>重置</button>
        </form>
    );
};

export default FileForm;
