// src/types.ts
export interface CaseTransfer {
    id: number;
    case_id: number;
    from_court_name: string;
    to_court_name: string;
    transferred_by: string;
    transfer_date: string;
    reason: string;
  }
  
  export interface CaseTransferFormData {
    case_id: string;
    from_court_id: string;
    to_court_id: string;
    transferred_by: string;
    transfer_date: string;
    reason: string;
  }
  